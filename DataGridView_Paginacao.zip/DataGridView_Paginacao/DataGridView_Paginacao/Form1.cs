﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DataGridView_Paginacao
{
    public partial class Form1 : Form
    {
        SqlDataAdapter daPaginacao;
        DataSet dsPaginado;
        DataTable dt;
        int regInicio;
        int registros;
        int quantidadeRegistrosPaginar;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCarregarDados_Click(object sender, EventArgs e)
        {
            try
            {
                quantidadeRegistrosPaginar = Convert.ToInt32(txtQuantidadeRegistros.Text);

                string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog=Northwind;Integrated Security=True";
                string sql = "SELECT * FROM Products";
                SqlConnection connection = new SqlConnection(connectionString);
                daPaginacao = new SqlDataAdapter(sql, connection);
                dsPaginado = new DataSet();
                dt = new DataTable();
                connection.Open();
                daPaginacao.Fill(dt);
                registros = dt.Rows.Count;
                daPaginacao.Fill(dsPaginado, regInicio, quantidadeRegistrosPaginar, "Products");
                connection.Close();
                dgvDados.DataSource = dsPaginado;
                dgvDados.DataMember = "Products";
            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro : " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnProximo_Click(object sender, EventArgs e)
        {
            regInicio = regInicio + quantidadeRegistrosPaginar;
            if (regInicio >= registros)
            {
                regInicio = registros - quantidadeRegistrosPaginar;
            }
            dsPaginado.Clear();
            //da.Fill(dataset, no. registro de inicio, qtde de registros a retornar, nome da tabela)
            daPaginacao.Fill(dsPaginado, regInicio, quantidadeRegistrosPaginar, "Products");
        }

        private void btnAnterior_Click(object sender, EventArgs e)
        {
            regInicio = regInicio - quantidadeRegistrosPaginar;
            if (regInicio <= 0)
            {
                regInicio = 0;
            }
            dsPaginado.Clear();
            daPaginacao.Fill(dsPaginado, regInicio, quantidadeRegistrosPaginar, "Products");
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            printDocument.Print();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap bm = new Bitmap(this.dgvDados.Width, this.dgvDados.Height);
            dgvDados.DrawToBitmap(bm, new Rectangle(0, 0, this.dgvDados.Width, this.dgvDados.Height));
            e.Graphics.DrawImage(bm, 0, 0);
        }
    }
}
